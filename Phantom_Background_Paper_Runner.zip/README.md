# SOL background paper test — prepared, not activated

This moves the existing $200 virtual SOL strategy into a GitHub Actions job. Your phone and Safari are not part of execution. It does not use Phantom, wallet keys, exchange credentials, paid data or ChatGPT tasks. It cannot trade real money. No profit advantage has been demonstrated.

## Activation remaining

Connect GitHub so the prepared files can be reviewed and installed. Use a new **public, paper-only repository**, or a verified suitable existing public repository. Do not change an existing private repository's visibility or copy wallet credentials into it. The public package contains only simulation code and virtual results. Never put personal data, real balances, keys, or tokens in these files.

Add the included files on the repository's default branch and enable the workflow. The workflow is intentionally skipped in private repositories to avoid using paid private-runner minutes. GitHub's standard hosted runners are free for public repositories. No artifact uploads or Actions caches are used. Source: https://docs.github.com/en/billing/concepts/product-billing/github-actions

In GitHub on your phone, open **Actions → SOL background paper test → Run workflow → tick**. Verify a successful run and the saved `paper-bot/data/STATUS.md`. Only then call the background test enabled. That first run starts a NEW $200 virtual wallet; it does not silently replace or claim to import the old Safari session.

## What runs while your phone is locked

The workflow requests a job every five minutes, offset from the top of the hour. Each job retrieves fresh SOL/USD reference data, loads the saved wallet, applies the strategy once, and commits its updated state. The next run reads that state. No long-running browser or continuously running VM is needed.

GitHub can delay or drop scheduled jobs. This is a low-cost paper experiment, not guaranteed five-minute execution or a suitable live-trading host. No missed entries or stop fills are reconstructed. Every gap over ten minutes is counted; stop and target exits use the next actual valid observation. Scheduled workflows only run on the default branch and may be disabled after 60 days of repository inactivity. Source: https://docs.github.com/en/actions/reference/workflows-and-actions/events-that-trigger-workflows#schedule

## Check and control from a phone

- Open `paper-bot/data/STATUS.md` for the latest report, or the Actions run summary. Check the last successful observation, not just whether a job says it ran. If that timestamp is older than 15 minutes, treat the runner and its valuation as stale even if the saved status says active.
- `paper-bot/data/status.json` is the public read-only dashboard feed. Once the repository is connected, the existing web dashboard can be pointed at it. That dashboard change is not activated by this package.
- **start** resumes entries after a normal pause; an active risk halt requires review and an explicit reset.
- **pause** pauses entries; an existing virtual position remains monitored by subsequent scheduled observations.
- **close** closes the virtual position at a fresh observed price and pauses entries.
- **reset** explicitly starts a new $200 paper wallet. Export results first. There are never real orders.
- To halt every scheduled observation, use GitHub's **Disable workflow** control. Do not delete the state file to pause it.

## Strategy assumptions

One SOL position; up to $20 principal plus costs. $40 cash reserve. Entry uses completed five-minute candles: EMA9 above EMA21, a close above six prior highs, volume at least 1.1 times the six-bar average, momentum no higher than 5%, and price drift no higher than 1%. At most five entries per UTC day; ten-minute post-exit cooldown. Default stop is a 5% decline in net liquidation value and target a 4% net gain. Positions time out after 12 hours at the next observation. A $10 daily equity loss or 8% peak drawdown halts entries.

Assumed costs are 0.3% fee, 0.3% adverse slippage, and $0.02 network cost per side. These are assumptions, not executable quotes. SOL/USD exchange references can differ materially from Phantom/on-chain swap prices. Trades and 360 equity observations are capped in the current JSON; Git history retains prior committed versions. This is not an independently audited track record.

## Validation

Run `node --test paper-bot/*.test.mjs`. To make one real public-data observation, run `python3 paper-bot/fetch_market.py | node paper-bot/observe.mjs`. Local data is written under `paper-bot/data/`. No third-party Python or npm packages are required.
