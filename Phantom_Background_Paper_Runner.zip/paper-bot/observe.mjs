import fs from 'node:fs';
import path from 'node:path';
import {pathToFileURL,fileURLToPath} from 'node:url';
import {newState,validateConfig,validateMarket,tick,equity,closePaper} from './engine.mjs';

export function freshRecord(now=Date.now()){
 const state=newState(now);state.enabled=true;
 return{schema:1,runCount:0,lastAttemptAt:null,lastSuccessAt:null,lastError:null,gapCount:0,maxGapMs:0,initialPrice:null,market:null,signal:null,state};
}
export function validateRecord(r){
 if(r?.schema!==1||!r.state||!Number.isFinite(r.runCount)||r.runCount<0)throw Error('Saved paper state is invalid; refusing to reset it.');
 const s=r.state;validateConfig(s.config);
 if(s.version!==1||!['cash','realized','fees','peak','dayStart','dayEntries','cooldownUntil'].every(k=>Number.isFinite(s[k]))||s.cash<0||s.fees<0||!Array.isArray(s.trades)||!Array.isArray(s.history))throw Error('Saved paper accounting is invalid.');
 if(s.history.some(p=>!Number.isFinite(p.t)||!Number.isFinite(p.v)))throw Error('Saved equity history is invalid.');
 if(s.position&&(!Number.isFinite(s.position.qty)||s.position.qty<=0||!Number.isFinite(s.position.cost)||s.position.cost<=0||!Number.isFinite(s.position.openedAt)))throw Error('Saved position is invalid.');
 return r;
}
export function observe(original,market,command='tick',now=Date.now()){
 if(!['tick','start','pause','close','reset'].includes(command))throw Error('Unknown paper command.');
 validateRecord(original);
 let r=command==='reset'?freshRecord(now):structuredClone(original);
 r.lastAttemptAt=now;r.runCount++;
 if(command==='pause')r.state.enabled=false;
 try{
  if(market?.error)throw Error(market.error);
  validateMarket(market,now);
  if(command==='start'){
   if(r.state.halted)throw Error('Risk pause is active. Review/export the log before an explicit reset.');
   r.state.enabled=true;
  }
  if(command==='close'){closePaper(r.state,market.price,now,'Manual cloud paper exit');r.state.enabled=false;}
  const gap=r.lastSuccessAt===null?0:now-r.lastSuccessAt;
  if(gap>600000){r.gapCount++;r.maxGapMs=Math.max(r.maxGapMs,gap);}
  const result=tick(r.state,market,now);
  r.state=result.state;r.signal=result.signal;
  r.market={price:market.price,quotedAt:market.quotedAt,fetchedAt:market.fetchedAt,source:market.source};
  r.lastSuccessAt=now;r.lastError=null;
  r.initialPrice??=market.price;
 }catch(error){r.lastError=String(error.message||error).slice(0,400);}
 return r;
}
export function summary(r,now=Date.now()){
 const price=r.market?.price,value=price?equity(r.state,price):r.state.history.at(-1)?.v??200;
 const age=r.lastSuccessAt===null?null:now-r.lastSuccessAt;
 return{mode:'paper-only',background:true,asOf:now,lastAttemptAt:r.lastAttemptAt,lastSuccessAt:r.lastSuccessAt,status:r.lastError?'feed-error':r.state.halted?'risk-paused':!r.state.enabled?'entries-paused':age===null?'not-started':age>900000?'stale':'active',
  error:r.lastError,runCount:r.runCount,gapCount:r.gapCount,maxGapMs:r.maxGapMs,price,source:r.market?.source,equity:value,net:value-200,realized:r.state.realized,fees:r.state.fees,cash:r.state.cash,position:r.state.position,decision:r.state.decision,signal:r.signal,
  buyHoldReference:r.initialPrice&&price?200*price/r.initialPrice:null,buyHoldCostsIncluded:false,config:r.state.config,history:r.state.history,trades:r.state.trades};
}
export function markdown(r){
 const s=summary(r),money=n=>Number(n).toFixed(2),date=n=>n?new Date(n).toISOString():'Never';
 return `# SOL cloud paper test\n\nStatus: **${s.status}**. No real orders or wallet access.\n\n| Metric | Value |\n| --- | --- |\n| Simulated equity | $${money(s.equity)} |\n| Net P/L | $${money(s.net)} |\n| Realized P/L | $${money(s.realized)} |\n| Assumed fees paid | $${money(s.fees)} |\n| Cash | $${money(s.cash)} |\n| Last successful observation | ${date(s.lastSuccessAt)} |\n| Last attempt | ${date(s.lastAttemptAt)} |\n| Observations with a gap over 10 minutes | ${s.gapCount} |\n\n${s.error?'Feed error: '+s.error.replaceAll('|','/'):'Decision: '+s.decision}\n\nThe scheduler can be late or skip runs. Stops are evaluated at the next observed price; no missed fills are invented. Indicative SOL/USD prices can differ from on-chain swaps. Profitability is unproven.\n`;
}
function atomicWrite(file,data){if(file instanceof URL)file=fileURLToPath(file);fs.mkdirSync(path.dirname(file),{recursive:true});const temp=file+'.tmp';fs.writeFileSync(temp,data);fs.renameSync(temp,file);}
export async function main(){
 const folder=new URL('./data/',import.meta.url),stateFile=new URL('state.json',folder),statusFile=new URL('status.json',folder),reportFile=new URL('STATUS.md',folder);
 let previous;
 try{previous=JSON.parse(fs.readFileSync(stateFile,'utf8'));}catch(error){if(error.code==='ENOENT')previous=freshRecord();else throw error;}
 const input=await new Promise((resolve,reject)=>{let text='';process.stdin.setEncoding('utf8');process.stdin.on('data',d=>{text+=d;if(text.length>500000)reject(Error('Market response too large.'));});process.stdin.on('end',()=>resolve(text));process.stdin.on('error',reject);});
 let market;try{market=JSON.parse(input);}catch{market={error:'Market response was not valid JSON.'};}
 const record=observe(previous,market,process.env.PAPER_COMMAND||'tick');
 const report=markdown(record);
 atomicWrite(stateFile,JSON.stringify(record,null,2)+'\n');atomicWrite(statusFile,JSON.stringify(summary(record),null,2)+'\n');atomicWrite(reportFile,report);
 if(process.env.GITHUB_STEP_SUMMARY)fs.appendFileSync(process.env.GITHUB_STEP_SUMMARY,report);
 console.log(JSON.stringify({mode:'paper-only',status:summary(record).status,lastSuccessAt:record.lastSuccessAt,fills:record.state.trades.length,error:record.lastError}));
 if(record.lastError)process.exitCode=1;
}
if(process.argv[1]&&import.meta.url===pathToFileURL(path.resolve(process.argv[1])).href){await main();}
