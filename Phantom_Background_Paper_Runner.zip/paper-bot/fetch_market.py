"""Public reference prices only; no wallet, API key, or order API."""
import concurrent.futures
import json
import time
import urllib.request

BASE = 'https://api.exchange.coinbase.com/products/SOL-USD'

def get(path):
    req = urllib.request.Request(BASE + path, headers={'Accept': 'application/json', 'User-Agent': 'SolPaperTest/1.0'})
    with urllib.request.urlopen(req, timeout=20) as response:
        return json.load(response)

def fetch_market():
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
        tick = pool.submit(get, '/ticker')
        candles = pool.submit(get, '/candles?granularity=300')
        tick, candles = tick.result(), candles.result()
    from datetime import datetime
    result = {
        'price': float(tick['price']),
        'quotedAt': round(datetime.fromisoformat(tick['time'].replace('Z', '+00:00')).timestamp() * 1000),
        'fetchedAt': round(time.time() * 1000),
        'source': 'Coinbase Exchange',
        'pool': 'SOL/USD reference prices',
        'candles': [dict(zip(('t', 'l', 'h', 'o', 'c', 'v'), map(float, row))) for row in candles[:100]],
    }
    return result

if __name__ == '__main__':
    try:
        print(json.dumps(fetch_market(), allow_nan=False))
    except Exception as error:
        # The observer saves this error without inventing fills or resetting cash.
        print(json.dumps({'error': str(error)[:400]}))
