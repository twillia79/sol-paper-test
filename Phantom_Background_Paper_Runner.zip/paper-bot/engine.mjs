export const DEFAULTS={stake:20,stopPct:5,targetPct:4,feePct:0.3,slipPct:0.3,networkUsd:0.02,reserve:40,dailyLoss:10,drawdownPct:8};
export function newState(now=Date.now()) {
 return {version:1,createdAt:now,cash:200,position:null,realized:0,fees:0,enabled:false,halted:'',day:new Date(now).toISOString().slice(0,10),dayStart:200,dayEntries:0,peak:200,lastBar:null,cooldownUntil:0,history:[{t:now,v:200}],trades:[],config:{...DEFAULTS},decision:'Start a paper session to test the rules.'};
}
export function validateConfig(c) {
 const bounds={stake:[5,20],stopPct:[1,20],targetPct:[1,30],feePct:[0,2],slipPct:[0,5],networkUsd:[0,1],reserve:[40,180],dailyLoss:[1,20],drawdownPct:[1,20]};
 for(const[k,[lo,hi]]of Object.entries(bounds))if(!Number.isFinite(c[k])||c[k]<lo||c[k]>hi)throw Error('Invalid setting: '+k);
 return c;
}
export function exitValue(p,price,c) {
 if(!p)return 0;
 return Math.max(0,p.qty*price*(1-c.slipPct/100)*(1-c.feePct/100)-c.networkUsd);
}
export function equity(s,price){return s.cash+(s.position?exitValue(s.position,price,s.config):0);}
export function getSignal(candles,price,now) {
 const bars=candles.filter(b=>b.t*1000+300000<=now).sort((a,b)=>a.t-b.t);
 if(bars.length<30)return{ready:false,bar:bars.at(-1)?.t??null,checks:[],reason:'Waiting for 30 completed candles.'};
 const last=bars.at(-1),prev=bars.slice(-7,-1);
 const ema=n=>bars.reduce((v,b,i)=>i?b.c*(2/(n+1))+v*(1-2/(n+1)):b.c,0);
 const high=Math.max(...prev.map(b=>b.h)),avg=prev.reduce((s,b)=>s+b.v,0)/prev.length;
 const ratio=avg>0?last.v/avg:0,change=last.c/prev[0].c-1,drift=Math.abs(price/last.c-1);
 const checks=[
 {name:'Upward trend',detail:'9-bar EMA above 21-bar EMA',pass:ema(9)>ema(21)},
 {name:'Breakout',detail:'Close above previous six highs',pass:last.c>high},
 {name:'Volume',detail:ratio.toFixed(2)+'× average · requires 1.10×',pass:ratio>=1.1},
 {name:'No large chase',detail:(change*100).toFixed(2)+'% six-bar move · maximum 5%',pass:change>=0&&change<=.05},
 {name:'Price drift',detail:(drift*100).toFixed(2)+'% from close · maximum 1%',pass:drift<=.01}];
 return{ready:checks.every(c=>c.pass),bar:last.t,checks,reason:checks.every(c=>c.pass)?'Entry conditions met.':checks.find(c=>!c.pass).name+' condition not met.'};
}
export function validateMarket(m,now) {
 if(!m||!Number.isFinite(m.price)||m.price<=0||!Number.isFinite(m.fetchedAt)||m.fetchedAt>now+30000||now-m.fetchedAt>90000)throw Error('Quote missing or older than 90 seconds.');
 if(m.quotedAt!==undefined&&(!Number.isFinite(m.quotedAt)||m.quotedAt>now+30000||now-m.quotedAt>90000))throw Error('Source trade timestamp is missing or stale.');
 if(!Array.isArray(m.candles)||m.candles.some(b=>![b.t,b.o,b.h,b.l,b.c,b.v].every(Number.isFinite)||b.c<=0||b.l<=0||b.o<=0||b.h<Math.max(b.o,b.c)||b.l>Math.min(b.o,b.c)||b.v<0))throw Error('Candle data is invalid.');
 const closed=m.candles.filter(b=>b.t*1000+300000<=now);
 if(closed.length<30||now-(Math.max(...closed.map(b=>b.t))*1000+300000)>900000)throw Error('Completed candle history is missing or stale.');
 return m;
}
export function closePaper(s,price,now,reason) {
 if(!s.position)return;
 const p=s.position,gross=p.qty*price*(1-s.config.slipPct/100),fee=gross*s.config.feePct/100+s.config.networkUsd;
 const proceeds=Math.max(0,gross-fee),pnl=proceeds-p.cost;
 s.cash+=proceeds;s.realized+=pnl;s.fees+=fee;s.position=null;s.cooldownUntil=now+600000;
 s.trades.push({t:now,side:'SELL',qty:p.qty,price,amount:proceeds,fee,pnl,reason});s.decision='Paper exit: '+reason;
}
export function tick(original,m,now=Date.now()) {
 validateConfig(original.config);validateMarket(m,now);
 const s=structuredClone(original),c=s.config,signal=getSignal(m.candles,m.price,now);
 let value=equity(s,m.price),day=new Date(now).toISOString().slice(0,10);
 if(day!==s.day){s.day=day;s.dayStart=value;s.dayEntries=0;if(s.halted==='Daily loss pause')s.halted='';}
 s.peak=Math.max(s.peak,value);
 const risk=value<=s.dayStart-c.dailyLoss?'Daily loss pause':value<=s.peak*(1-c.drawdownPct/100)?'Drawdown pause':'';
 if(risk){s.halted=risk;s.enabled=false;if(s.position)closePaper(s,m.price,now,risk);}
 if(s.position){const gain=exitValue(s.position,m.price,c)/s.position.cost-1;
  if(gain<=-c.stopPct/100)closePaper(s,m.price,now,'Stop-loss trigger');
  else if(gain>=c.targetPct/100)closePaper(s,m.price,now,'Profit target');
  else if(now-s.position.openedAt>=43200000)closePaper(s,m.price,now,'12-hour time exit');
 }
 const freshBar=signal.bar!==s.lastBar;
 if(!s.position&&s.enabled&&!s.halted){
  if(now<s.cooldownUntil)s.decision='Ten-minute cooldown after the last exit.';
  else if(s.dayEntries>=5)s.decision='Five-entry daily limit reached.';
  else if(!freshBar)s.decision='Waiting for the next completed five-minute candle.';
  else if(!signal.ready)s.decision=signal.reason;
  else{const stake=Math.min(c.stake,Math.max(0,s.cash-c.reserve-c.networkUsd)/(1+c.feePct/100)),fee=stake*c.feePct/100+c.networkUsd;
   if(stake<5||s.cash-stake-fee<c.reserve)s.decision='Cash reserve prevents a new entry.';
   else{const qty=stake/(m.price*(1+c.slipPct/100));s.cash-=stake+fee;s.fees+=fee;s.dayEntries++;
    s.position={qty,cost:stake+fee,openedAt:now,entryPrice:m.price};s.trades.push({t:now,side:'BUY',qty,price:m.price,amount:stake+fee,fee,pnl:null,reason:'Five-minute volume breakout'});s.decision='Paper entry: volume breakout.';}
  }
 }else if(!s.enabled&&!s.position&&!risk)s.decision=s.halted||'Entries paused. Start when you want to test.';
 s.lastBar=signal.bar;value=equity(s,m.price);
 if(!s.history.length||now-s.history.at(-1).t>=30000)s.history.push({t:now,v:value});
 s.history=s.history.slice(-360);s.trades=s.trades.slice(-250);
 return{state:s,signal};
}
let marketCache=null;
async function provider(path){const r=await fetch('https://api.exchange.coinbase.com/products/SOL-USD'+path,{headers:{Accept:'application/json'},signal:AbortSignal.timeout(15000)});if(!r.ok)throw Error(r.status===429?'Market provider rate limit. Try again in a minute.':'Market provider unavailable ('+r.status+').');return r.json();}
export async function getMarket(){
 const now=Date.now();if(marketCache&&now-marketCache.fetchedAt<30000)return marketCache;
 const[t,h]=await Promise.all([provider('/ticker'),provider('/candles?granularity=300')]);
 if(!Array.isArray(h))throw Error('Invalid candle response.');
 const result={price:Number(t.price),quotedAt:Date.parse(t.time),candles:h.slice(0,100).map(r=>({t:Number(r[0]),o:Number(r[3]),h:Number(r[2]),l:Number(r[1]),c:Number(r[4]),v:Number(r[5])})),fetchedAt:Date.now(),source:'Coinbase Exchange',pool:'SOL/USD reference prices',poolAddress:null};
 validateMarket(result,Date.now());marketCache=result;return result;
}
