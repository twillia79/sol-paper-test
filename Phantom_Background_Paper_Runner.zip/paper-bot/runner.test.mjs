import {test} from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {spawnSync} from 'node:child_process';
import {freshRecord,observe,summary,validateRecord} from './observe.mjs';

const now=Date.UTC(2026,10,1,12,0);
function market(price=101,at=now){
 const candles=Array.from({length:40},(_,i)=>{const c=100+i*.02;return{t:at/1000-(40-i)*300,o:c-.01,h:c+.02,l:c-.02,c,v:100};});
 Object.assign(candles.at(-1),{o:100.8,h:101.02,l:100.78,c:101,v:150});
 return{price,candles,fetchedAt:at,quotedAt:at,source:'test fixture'};
}
test('scheduled observations continue across independent process restarts',()=>{
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'sol-paper-restart-'));
 try{
  for(const name of ['engine.mjs','observe.mjs'])fs.copyFileSync(new URL(name,import.meta.url),path.join(dir,name));
  const command=price=>spawnSync(process.execPath,[path.join(dir,'observe.mjs')],{input:JSON.stringify(market(price,Date.now())),encoding:'utf8',env:{...process.env,PAPER_COMMAND:'tick',GITHUB_STEP_SUMMARY:''}});
  const first=command(101);assert.equal(first.status,0,first.stderr);
  let record=JSON.parse(fs.readFileSync(path.join(dir,'data/state.json')));assert.equal(record.state.trades.length,1);assert.ok(Math.abs(record.state.cash-179.92)<1e-9);
  const second=command(108);assert.equal(second.status,0,second.stderr);
  record=JSON.parse(fs.readFileSync(path.join(dir,'data/state.json')));assert.equal(record.runCount,2);assert.equal(record.state.position,null);assert.equal(record.state.trades.length,2);assert.ok(Math.abs(record.state.cash-200-record.state.realized)<1e-9);
  assert.match(fs.readFileSync(path.join(dir,'data/STATUS.md'),'utf8'),/SOL cloud paper test/);
 }finally{fs.rmSync(dir,{recursive:true,force:true});}
});
test('feed failure preserves the position, cash and last success',()=>{
 const entered=observe(freshRecord(now),market(),'tick',now),r=observe(entered,{error:'Feed unavailable'},'tick',now+300000);
 assert.equal(r.lastSuccessAt,now);assert.equal(r.lastAttemptAt,now+300000);assert.equal(r.lastError,'Feed unavailable');assert.deepEqual(r.state,entered.state);assert.equal(summary(r,now+300000).status,'feed-error');
});
test('late observations count a data gap and use observed price for exits',()=>{
 const entered=observe(freshRecord(now),market(),'tick',now),later=now+1200000;
 const r=observe(entered,market(90,later),'tick',later);
 assert.equal(r.gapCount,1);assert.equal(r.maxGapMs,1200000);assert.equal(r.state.trades.length,2);assert.equal(r.state.trades.at(-1).price,90);assert.equal(r.state.trades.at(-1).reason,'Stop-loss trigger');
});
test('manual pause persists but existing position exits remain monitored',()=>{
 const entered=observe(freshRecord(now),market(),'tick',now);
 const paused=observe(entered,market(101,now+300000),'pause',now+300000);assert.equal(paused.state.enabled,false);assert.ok(paused.state.position);
 const exited=observe(paused,market(108,now+600000),'tick',now+600000);assert.equal(exited.state.enabled,false);assert.equal(exited.state.position,null);
});
test('stale source prices do not create fills or manufacture success',()=>{
 const m=market();m.quotedAt=now-90001;const r=observe(freshRecord(now),m,'tick',now);
 assert.equal(r.state.cash,200);assert.equal(r.state.trades.length,0);assert.equal(r.lastSuccessAt,null);assert.match(r.lastError,/stale/);
});
test('invalid saved accounting is rejected rather than silently reset',()=>{
 const r=freshRecord(now);r.state.cash='invalid';assert.throws(()=>validateRecord(r),/accounting/);assert.throws(()=>observe(r,market(),'tick',now),/accounting/);
});
test('risk halt prevents manual restart until an explicit reset',()=>{
 const entered=observe(freshRecord(now),market(),'tick',now),later=now+300000;
 const halted=observe(entered,market(30,later),'tick',later);assert.equal(halted.state.halted,'Daily loss pause');assert.equal(halted.state.enabled,false);
 const restart=observe(halted,market(101,later),'start',later);assert.equal(restart.state.enabled,false);assert.match(restart.lastError,/Risk pause/);
 const reset=observe(halted,market(101,later),'reset',later);assert.equal(reset.state.halted,'');assert.equal(reset.state.trades.length,1);
});
test('summary flags a stale active runner and never promises current valuation',()=>{
 const r=observe(freshRecord(now),market(),'tick',now);assert.equal(summary(r,now+1000000).status,'stale');assert.equal(summary(r,now).mode,'paper-only');
});
